#!/bin/sh

ip="172.16.5.69"

while [ "1" = "1" ];
do
    sudo ./syn_act $ip
done